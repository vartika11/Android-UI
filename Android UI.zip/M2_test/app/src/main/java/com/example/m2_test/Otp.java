package com.example.m2_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.m2_test.databinding.ActivityOtpBinding;

import in.aabhasjindal.otptextview.OTPListener;

public class Otp extends AppCompatActivity {
    TextView t1;
    Button bt1;
    ImageView im1;
    ActivityOtpBinding activityOtpBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityOtpBinding= DataBindingUtil.setContentView(Otp.this,R.layout.activity_otp);
        activityOtpBinding.otpView.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {

            }

            @Override
            public void onOTPComplete(String otp) {
                Toast.makeText(Otp.this,"The OTP is " + otp, Toast.LENGTH_SHORT).show();

            }
        });

        setContentView(R.layout.activity_otp);
        im1=(ImageView)findViewById(R.id.tic);
        im1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Otp.this,Sign_up.class);
                startActivity(intent);
            }

        });

        t1=(TextView)findViewById(R.id.verify);
                t1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(Otp.this,Otp.class);
                        startActivity(intent);
                    }
                });
                bt1=(Button)findViewById(R.id.option);
                bt1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(Otp.this,Reset_pass.class);
                        startActivity(intent);
                    }
                });

    }
}
