package com.example.m2_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.m2_test.databinding.ActivitySignUpBinding;

import java.util.regex.Pattern;

public class Sign_up extends AppCompatActivity {
    ActivitySignUpBinding activitySignUpBinding;
    Button bt1;
    TextView t1,t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activitySignUpBinding= DataBindingUtil.setContentView(Sign_up.this,R.layout.activity_sign_up);
        bt1=(Button) findViewById(R.id.button);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPhone()&& isPassword()) {

                    Intent intent = new Intent(Sign_up.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(Sign_up.this,"Sign UP successful",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Sign_up.this,"Please check all the fields",Toast.LENGTH_SHORT).show();
                }
                }

        });
        t2=(TextView)findViewById(R.id.forgot);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Sign_up.this,Otp.class);
                startActivity(intent);
            }
        });
        t1=(TextView)findViewById(R.id.sign_upTv);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Sign_up.this,Login.class);
                startActivity(intent);
            }
        });

        activitySignUpBinding.text2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String phnNum = activitySignUpBinding.text2.getText().toString().trim();
                if (phnNum.length()<1){
                    activitySignUpBinding.phTv.setVisibility(View.VISIBLE);
                    activitySignUpBinding.phTv.setText("*Enter the number.");
                }
                else if (Pattern.compile("[0-9]{8,12}").matcher(phnNum).matches()){
                    activitySignUpBinding.phTv.setVisibility(View.INVISIBLE);
                }
                else{
                    activitySignUpBinding.phTv.setVisibility(View.VISIBLE);
                    activitySignUpBinding.phTv.setText("*Enter valid number.");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        activitySignUpBinding.passEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String pass= activitySignUpBinding.passEt.getText().toString().trim();
                if (pass.length()<1){
                    activitySignUpBinding.passTv.setVisibility(View.VISIBLE);
                    activitySignUpBinding.passTv.setText("Enter the password");
                }
                else if (pass.length()<8){
                    activitySignUpBinding.passTv.setVisibility(View.VISIBLE);
                }
                else{
                    activitySignUpBinding.passTv.setVisibility(View.INVISIBLE);


                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    boolean isPhone() {
        String phnNum = activitySignUpBinding.text2.getText().toString().trim();
        if (phnNum.length() < 1) {
            activitySignUpBinding.phTv.setVisibility(View.VISIBLE);
            activitySignUpBinding.phTv.setText("*Enter the number.");
            return  false;

        } else if (Pattern.compile("[0-9]{8,12}").matcher(phnNum).matches()) {
            activitySignUpBinding.phTv.setVisibility(View.INVISIBLE);
            return  true;
        } else {
            activitySignUpBinding.phTv.setVisibility(View.VISIBLE);
            activitySignUpBinding.phTv.setText("*Enter valid name.");
            return  false;
        }

    }

     boolean isPassword(){
        String pass= activitySignUpBinding.passEt.getText().toString().trim();
        if (pass.length()<1){
            activitySignUpBinding.passTv.setVisibility(View.VISIBLE);
            activitySignUpBinding.passTv.setText("Enter the password");
            return  false;
        }
        else if (pass.length()<8){
            activitySignUpBinding.passTv.setVisibility(View.VISIBLE);
            return  false;
        }
        else{
            activitySignUpBinding.passTv.setVisibility(View.INVISIBLE);
             return  true;
        }


    }
}
