package com.example.m2_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;

import com.example.m2_test.databinding.ActivityResetPassBinding;

public class Reset_pass extends AppCompatActivity {
    Button bt1;
    ActivityResetPassBinding activityResetPassBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pass);
        bt1=(Button)findViewById(R.id.reset);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Reset_pass.this,Sign_up.class);
                startActivity(intent);
            }
        });
        activityResetPassBinding.oldEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String pass= activityResetPassBinding.oldEt.getText().toString().trim();
                if (pass.length()<1){
                    activityResetPassBinding.oldTv.setVisibility(View.VISIBLE);
                    activityResetPassBinding.oldTv.setText("Enter the password");
                }
                else if (pass.length()<8){
                    activityResetPassBinding.oldTv.setVisibility(View.VISIBLE);
                }
                else{
                    activityResetPassBinding.oldTv.setVisibility(View.INVISIBLE);


                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        activityResetPassBinding.oldEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String pass= activityResetPassBinding.oldEt.getText().toString().trim();
                if (pass.length()<1){
                    activityResetPassBinding.oldTv.setVisibility(View.VISIBLE);
                    activityResetPassBinding.oldTv.setText("Enter the password");
                }
                else if (pass.length()<8){
                    activityResetPassBinding.oldTv.setVisibility(View.VISIBLE);
                }
                else{
                    activityResetPassBinding.oldTv.setVisibility(View.INVISIBLE);


                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
