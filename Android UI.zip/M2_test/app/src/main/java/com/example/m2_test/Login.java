package com.example.m2_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.m2_test.databinding.ActivityLoginBinding;

import java.util.regex.Pattern;

public class Login extends AppCompatActivity {
    ActivityLoginBinding activityLoginBinding;
     String password;
    TextView t2;
    Button bt2;

    EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityLoginBinding= DataBindingUtil.setContentView(this,R.layout.activity_login);



        bt2=(Button) findViewById(R.id.button2);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFrstName()&& isLastName() && isPhn() && isPass() && isCnPass()) {
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(Login.this,"Sign UP successful",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Login.this,"Please check all the fields",Toast.LENGTH_SHORT).show();
                }
            }
        });
        t2=(TextView)findViewById(R.id.condition);
       t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Login.this,Terms.class);
                startActivity(intent);
            }
        });


       activityLoginBinding.fnmEt.addTextChangedListener(new TextWatcher() {
           @Override
           public void beforeTextChanged(CharSequence s, int start, int count, int after) {

           }

           @Override
           public void onTextChanged(CharSequence s, int start, int before, int count) {
               String fname=activityLoginBinding.fnmEt.getText().toString().trim();
               if (fname.length()<1){
                   activityLoginBinding.fnmTv.setVisibility(View.VISIBLE);
                   activityLoginBinding.fnmTv.setText("Enter the name");
               }
               else if (Pattern.compile("[A-Za-z]{0,15}").matcher(fname).matches()){
                   activityLoginBinding.fnmTv.setVisibility(View.INVISIBLE);
               }

               else{
                   activityLoginBinding.fnmTv.setVisibility(View.VISIBLE);
                   activityLoginBinding.fnmTv.setText("Enter valid name");
               }

           }

           @Override
           public void afterTextChanged(Editable s) {

           }

       });
        activityLoginBinding.lnmeEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String lname=activityLoginBinding.lnmeEt.getText().toString().trim();
                if (lname.length()<1){
                    activityLoginBinding.lnmeTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.lnmeTv.setText("Enter the name");
                }
                else if (Pattern.compile("[A-Za-z]{0,15}").matcher(lname).matches()){
                    activityLoginBinding.lnmeTv.setVisibility(View.INVISIBLE);
                }

                else{
                    activityLoginBinding.lnmeTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.lnmeTv.setText("Enter valid name");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        activityLoginBinding.phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String phnNum = activityLoginBinding.phone.getText().toString().trim();
                if (phnNum.length()<1){
                    activityLoginBinding.phonTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.phonTv.setText("*Enter the number.");
                }
                else if (Pattern.compile("[0-9]{8,12}").matcher(phnNum).matches()){
                    activityLoginBinding.phonTv.setVisibility(View.INVISIBLE);
                }
                else{
                    activityLoginBinding.phonTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.phonTv.setText("*Enter valid number.");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        activityLoginBinding.passwordEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                password= activityLoginBinding.passwordEt.getText().toString().trim();
                if (password.length()<1){
                    activityLoginBinding.passwordTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.passwordTv.setText("Password is too short");
                }
                else if (password.length()<8){
                    activityLoginBinding.passwordTv.setVisibility(View.VISIBLE);
                }
                else{
                    activityLoginBinding.passwordTv.setVisibility(View.INVISIBLE);

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        activityLoginBinding.cpassEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String cnpassword= activityLoginBinding.cpassEt.getText().toString().trim();
                if (cnpassword.length()<1){
                    activityLoginBinding.cpassTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.cpassTv.setText("Password is too short");
                }
               else if (Pattern.compile(password).matcher(cnpassword).matches()){
                    activityLoginBinding.cpassTv.setVisibility(View.INVISIBLE);

                }
               else {
                    activityLoginBinding.cpassTv.setVisibility(View.VISIBLE);
                    activityLoginBinding.cpassTv.setText("Password doesn't match");

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });






    }
    boolean isFrstName(){
        String fname=activityLoginBinding.fnmEt.getText().toString().trim();
        if (fname.length()<1){
            activityLoginBinding.fnmTv.setVisibility(View.VISIBLE);
            activityLoginBinding.fnmTv.setText("Enter the name");
            return false;
        }
        else if (Pattern.compile("[A-Za-z]{0,15}").matcher(fname).matches()){
            activityLoginBinding.fnmTv.setVisibility(View.INVISIBLE);
            return true;
        }

        else{
            activityLoginBinding.fnmTv.setVisibility(View.VISIBLE);
            activityLoginBinding.fnmTv.setText("Enter valid name");
            return false;
        }

    }
    boolean isLastName(){
        String lname=activityLoginBinding.lnmeEt.getText().toString().trim();
        if (lname.length()<1){
            activityLoginBinding.lnmeTv.setVisibility(View.VISIBLE);
            activityLoginBinding.lnmeTv.setText("Enter the name");
            return false;
        }
        else if (Pattern.compile("[A-Za-z]{0,15}").matcher(lname).matches()){
            activityLoginBinding.lnmeTv.setVisibility(View.INVISIBLE);
            return true;
        }

        else{
            activityLoginBinding.lnmeTv.setVisibility(View.VISIBLE);
            activityLoginBinding.lnmeTv.setText("Enter valid name");
            return false;
        }

    }
    boolean isPhn(){
        String phnNum = activityLoginBinding.phone.getText().toString().trim();
        if (phnNum.length()<1){
            activityLoginBinding.phonTv.setVisibility(View.VISIBLE);
            activityLoginBinding.phonTv.setText("*Enter the number.");
            return false;
        }
        else if (Pattern.compile("[0-9]{8,12}").matcher(phnNum).matches()){
            activityLoginBinding.phonTv.setVisibility(View.INVISIBLE);
            return true;
        }
        else{
            activityLoginBinding.phonTv.setVisibility(View.VISIBLE);
            activityLoginBinding.phonTv.setText("*Enter valid name.");
            return false;
        }

    }

    boolean isPass(){
        password= activityLoginBinding.passwordEt.getText().toString().trim();
        if (password.length()<1){
            activityLoginBinding.passwordTv.setVisibility(View.VISIBLE);
            activityLoginBinding.passwordTv.setText("Password is too short");
            return false;
        }
        else if (password.length()<8){
            activityLoginBinding.passwordTv.setVisibility(View.VISIBLE);
            return false;
        }
        else{
            activityLoginBinding.passwordTv.setVisibility(View.INVISIBLE);
            return true;

        }

    }
    boolean isCnPass(){
        String cnpassword= activityLoginBinding.cpassEt.getText().toString().trim();
        if (cnpassword.length()<1){
            activityLoginBinding.cpassTv.setVisibility(View.VISIBLE);
            activityLoginBinding.cpassTv.setText("Password is too short");
            return false;

        }
        else if (Pattern.compile(password).matcher(cnpassword).matches()){
            activityLoginBinding.cpassTv.setVisibility(View.INVISIBLE);
            return true;

        }
        else {
            activityLoginBinding.cpassTv.setVisibility(View.VISIBLE);
            activityLoginBinding.cpassTv.setText("Password doesn't match");
            return false;


        }

    }
}
